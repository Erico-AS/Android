package com.example.lista_20

data class spotify(var idFoto: Int, var texto: String)
